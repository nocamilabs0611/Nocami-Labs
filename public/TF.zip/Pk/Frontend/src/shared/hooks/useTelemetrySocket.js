import { useState, useEffect, useRef } from 'react';
import { API_CONFIG } from '../../config/appConfig';

/**
 * Custom React hook for live WebSocket telemetry from backend
 * Connects to ws://localhost:8000/ws/telemetry with auto-reconnect
 */
export function useTelemetrySocket(customUrl = null) {
  const url = customUrl || API_CONFIG.WS_URL;
  const [telemetryData, setTelemetryData] = useState({
    timestamp: Date.now(),
    activeAgvs: 18,
    totalAgvs: 22,
    pipelineStatus: 'Connected',
    aisleBCongestion: 87,
    agvs: [],
    isConnected: false,
  });

  const [isConnected, setIsConnected] = useState(false);
  const socketRef = useRef(null);
  const reconnectTimeoutRef = useRef(null);

  useEffect(() => {
    // If mock mode is explicitly forced in config, don't attempt real WS
    if (API_CONFIG.USE_MOCK) {
      return;
    }

    let isMounted = true;

    const connect = () => {
      try {
        const ws = new WebSocket(url);
        socketRef.current = ws;

        ws.onopen = () => {
          if (!isMounted) return;
          setIsConnected(true);
        };

        ws.onmessage = (event) => {
          if (!isMounted) return;
          try {
            const data = JSON.parse(event.data);
            setTelemetryData({
              ...data,
              isConnected: true,
            });
          } catch (err) {
            console.warn('[useTelemetrySocket] Failed to parse telemetry frame:', err);
          }
        };

        ws.onclose = () => {
          if (!isMounted) return;
          setIsConnected(false);
          // Auto reconnect after 3 seconds
          reconnectTimeoutRef.current = setTimeout(connect, 3000);
        };

        ws.onerror = () => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.close();
          }
        };
      } catch (err) {
        console.warn('[useTelemetrySocket] Error creating WebSocket:', err);
        if (isMounted) {
          reconnectTimeoutRef.current = setTimeout(connect, 4000);
        }
      }
    };

    connect();

    return () => {
      isMounted = false;
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
      if (socketRef.current) {
        try {
          socketRef.current.close();
        } catch {}
      }
    };
  }, [url]);

  return { telemetryData, isConnected };
}

export default useTelemetrySocket;
