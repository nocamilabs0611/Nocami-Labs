import React from 'react';
import AdminAlertsView from '../admin/AdminAlertsView';

export default function UserAlertsView(props) {
  return <AdminAlertsView {...props} isAdmin={false} />;
}
