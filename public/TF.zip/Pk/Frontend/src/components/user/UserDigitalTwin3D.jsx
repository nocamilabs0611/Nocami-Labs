import React from 'react';
import AdminDigitalTwin3D from '../admin/AdminDigitalTwin3D';

export default function UserDigitalTwin3D(props) {
  return <AdminDigitalTwin3D {...props} isAdmin={false} />;
}
