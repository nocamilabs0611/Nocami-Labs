export { default } from '../admin/WarehouseMap';
