import React from 'react';
import AdminWhatIfSimulationView from '../admin/AdminWhatIfSimulationView';

export default function UserWhatIfSimulationView(props) {
  return <AdminWhatIfSimulationView {...props} isAdmin={false} />;
}
