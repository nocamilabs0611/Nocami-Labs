import React from 'react';
import AdminAIPredictionsView from '../admin/AdminAIPredictionsView';

export default function UserAIPredictionsView(props) {
  return <AdminAIPredictionsView {...props} isAdmin={false} />;
}
