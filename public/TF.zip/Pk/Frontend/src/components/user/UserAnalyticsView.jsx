import React from 'react';
import AdminAnalyticsView from '../admin/AdminAnalyticsView';

export default function UserAnalyticsView(props) {
  return <AdminAnalyticsView {...props} isAdmin={false} />;
}
