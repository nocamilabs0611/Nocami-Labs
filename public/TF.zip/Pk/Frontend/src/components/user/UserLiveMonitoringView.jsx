import React from 'react';
import AdminLiveMonitoringView from '../admin/AdminLiveMonitoringView';

export default function UserLiveMonitoringView(props) {
  return <AdminLiveMonitoringView {...props} isAdmin={false} />;
}
