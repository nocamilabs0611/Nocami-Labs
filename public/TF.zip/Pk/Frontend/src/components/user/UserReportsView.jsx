import React from 'react';
import AdminReportsView from '../admin/AdminReportsView';

export default function UserReportsView(props) {
  return <AdminReportsView {...props} isAdmin={false} />;
}
