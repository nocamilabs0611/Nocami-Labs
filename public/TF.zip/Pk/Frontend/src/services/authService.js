/**
 * Authentication & Session Service
 */
import apiClient from './apiClient.js';

const MOCK_USERS = {
  admin: {
    username: 'admin',
    role: 'admin',
    displayName: 'Sarah Lin',
    email: 'admin@twinflow.ai',
    accessLevel: 'Full Administrative & Topology Access',
  },
  operator: {
    username: 'operator',
    role: 'user',
    displayName: 'Sam Haddad',
    email: 'operator@twinflow.ai',
    accessLevel: 'Real-time Congestion Monitoring',
  },
};

export const authService = {
  async login({ username, password }) {
    const res = await apiClient.post(
      '/auth/login',
      { username, password },
      () => {
        const user = MOCK_USERS[username.toLowerCase()] || {
          username,
          role: 'user',
          displayName: username,
          email: `${username}@twinflow.ai`,
          accessLevel: 'Standard Operations Access',
        };
        const token = `mock-token-${Date.now()}`;
        return { success: true, user, token };
      },
      300
    );

    if (res && res.token) {
      apiClient.setToken(res.token);
      if (typeof window !== 'undefined' && window.sessionStorage && res.user) {
        window.sessionStorage.setItem('twinflow_user', JSON.stringify(res.user));
      }
    }
    return res;
  },

  async logout() {
    apiClient.setToken(null);
    if (typeof window !== 'undefined' && window.sessionStorage) {
      window.sessionStorage.removeItem('twinflow_user');
      window.sessionStorage.removeItem('twinflow_token');
    }
    return apiClient.post('/auth/logout', null, { success: true }, 100);
  },

  getStoredSession() {
    if (typeof window === 'undefined' || !window.sessionStorage) return null;
    const userStr = window.sessionStorage.getItem('twinflow_user');
    const token = window.sessionStorage.getItem('twinflow_token');
    if (userStr && token) {
      try {
        const user = JSON.parse(userStr);
        apiClient.setToken(token);
        return user;
      } catch {
        return null;
      }
    }
    return null;
  },

  getMockPersona(role = 'admin') {
    return role === 'admin' ? MOCK_USERS.admin : MOCK_USERS.operator;
  },
};

export default authService;
