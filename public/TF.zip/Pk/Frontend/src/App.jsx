import React, { useState } from 'react';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import { authService } from './services/authService';

export default function App() {
  // Current user state (restored from active session if available)
  const [currentUser, setCurrentUser] = useState(() => authService.getStoredSession());

  // Handle successful login from LoginPage
  const handleLoginSuccess = (userData) => {
    setCurrentUser(userData);
  };

  // Direct preview of Dashboard mockup (from header button on login page)
  const handleDirectDashboardPreview = (role = 'admin') => {
    const persona = authService.getMockPersona(role);
    setCurrentUser(persona);
    if (typeof window !== 'undefined' && window.sessionStorage) {
      window.sessionStorage.setItem('twinflow_user', JSON.stringify(persona));
      window.sessionStorage.setItem('twinflow_token', `demo-preview-${role}`);
    }
  };

  // Logout handler
  const handleLogout = () => {
    authService.logout();
    setCurrentUser(null);
  };

  // Quick switch role between Admin & Operator while on Dashboard
  const handleSwitchRole = () => {
    if (!currentUser) return;
    if (currentUser.role === 'admin') {
      setCurrentUser({
        username: 'operator',
        role: 'user',
        displayName: 'Floor Lead Operator',
        email: 'operator@twinflow.ai',
        accessLevel: 'Real-time Congestion Monitoring',
      });
    } else {
      setCurrentUser({
        username: 'admin',
        role: 'admin',
        displayName: 'Warehouse System Admin',
        email: 'admin@twinflow.ai',
        accessLevel: 'Full Administrative & Topology Access',
      });
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans">
      {!currentUser ? (
        <LoginPage
          onLoginSuccess={handleLoginSuccess}
          onDirectDashboardPreview={handleDirectDashboardPreview}
        />
      ) : (
        <Dashboard
          currentUser={currentUser}
          onLogout={handleLogout}
          onSwitchRole={handleSwitchRole}
        />
      )}
    </div>
  );
}
